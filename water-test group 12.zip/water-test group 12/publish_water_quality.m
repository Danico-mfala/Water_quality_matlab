% run_publish.m
publish('water_quality.m', 'html');
